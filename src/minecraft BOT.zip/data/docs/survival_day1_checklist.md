# Day 1 — Survival Checklist

- [ ] Collect 6–10 **logs** and turn them into **planks**.
- [ ] Craft a **crafting table** and **sticks**.
- [ ] Make a **wooden pickaxe** (temporary) → gather **20 cobblestone**.
- [ ] Craft **stone tools** (pickaxe/axe/shovel).
- [ ] **Furnace** + **charcoal** → **torches**.
- [ ] **Lighted** shelter before night.
- [ ] Cook **8–12 food** items.
- [ ] Make a **chest** to organize.
