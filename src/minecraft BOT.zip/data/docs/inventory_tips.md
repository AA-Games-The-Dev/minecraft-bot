# Inventory & Organization Tips

- Keep 8–12 cooked **foods** in your hotbar.
- Carry enough **torches** for mining (every 8–12 blocks).
- Bring extra **wood** to craft tools on the go.
- Make a **double chest** to organize (two chests side by side).
