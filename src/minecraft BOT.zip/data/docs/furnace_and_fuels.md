# Furnace & Fuels

## Furnace
- Recipe: 8 cobblestone around (empty center).
- Use: item on top, fuel below.

## Fuels
- **Coal / Charcoal:** very efficient.
- **Wood / Planks / Sticks:** work but burn shorter.
- Tip: use wood early; later switch to coal.

## Charcoal
- Smelt **logs** in the furnace to produce **charcoal**.
- Charcoal replaces coal for torches and as fuel.
