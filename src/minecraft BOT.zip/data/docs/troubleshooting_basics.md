# Troubleshooting — Basics

**I can’t sprint.**
Your **hunger** is ≤ 6. Eat until it’s full.

**I mined coal but got no item.**
Check if you’re using a **pickaxe**. Some blocks require the correct tool.

**I don’t see the 3×3 crafting grid.**
Craft a **Crafting Table** (4 planks) and right‑click it.

**I died and lost everything.**
Return to the death location quickly; items **despawn** after a few minutes.
