# Mini‑FAQ for the Bot (short questions → direct answers)

**How do I get wood?**
Stand next to a tree log and **hold left click** until it breaks; pick up the item.

**How do I open the crafting table?**
Place it on the ground and **right‑click**.

**How do I make sticks?**
1 plank **above** 1 plank → 4 sticks.

**I have no coal!**
Make **charcoal**: smelt logs in the **furnace** (fuel below).

**I can’t sprint!**
Eat until **hunger** is above 6 points.

**I get lost easily. Tips?**
Dirt **totems** with a **torch** on top + write down **coordinates** (F3 on Java).

**I died. Now what?**
Return to your **spawn point** (last bed used). Grab your items where you died **before they despawn** (a few minutes).
