# Mini‑FAQ para o Bot (perguntas curtinhas → respostas diretas)

**Como pego madeira?**  
Chegue no tronco e segure **botão esquerdo** até quebrar; pegue o item no chão.

**Como abro a bancada?**  
Coloque no chão e use **botão direito**.

**Como faço gravetos?**  
1 tábua **em cima** de 1 tábua → 4 gravetos.

**Não tenho carvão mineral!**  
Faça **carvão vegetal**: cozinhe troncos na **fornalha** (combustível embaixo).

**Não consigo correr!**  
Coma até encher a **fome** (> 6 pontos).

**Me perco fácil. Dicas?**  
Totens de terra com **tocha** no topo + anote **coordenadas** (F3 no Java).

**Morri. E agora?**  
Volta no **ponto de spawn** (última cama usada). Pegue seus itens onde morreu **antes de sumirem** (alguns min).

